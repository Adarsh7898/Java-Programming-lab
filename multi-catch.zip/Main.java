/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    String a=null;
	    int arr[]={1,2,3};
	    try{
	        System.out.println(a.length());
	        System.out.println(arr[2]);
	    }
	    catch(ArrayIndexOutOfBoundsException e1)
	    {
	    System.out.println("Exception index out of bounds "+e1);
	}
	catch(NullPointerException e2)
	{
	    System.out.println("Exception Null pointer "+e2);
	}
}
}