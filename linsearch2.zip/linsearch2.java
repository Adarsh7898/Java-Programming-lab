




public class linsearch2
{
    public  int linearsearch(int[]arr,int key){
        for(int i=0;i<arr.length;i++)
        if(arr[i]==key){
            return i;
        }
        return-1;
    }
	public static void main(String[] args) {
	    int a[]= {1,2,3,4,5};
	    int key=4;
	    linsearch2 L=new linsearch2();
	    L.linearsearch(a,key);
		System.out.println(key+" is found at index:");
	}
}