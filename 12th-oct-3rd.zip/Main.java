final class finalClass
{
	 {
	    public  void display(){
	        System.out.println("Hello World");
	    }
		
	}
class Main extends finalClass{
	    System.out.println("Hello World");
	}
	public static void main(String args[])
	{
	    Main obj=new Main();
	    obj.display();
	}
}

