






public class TwoD
{
	public static void main(String[] args) {
	    int a[][]={{2,3},{9,0},{4,6}};
		System.out.println("The array is");
		for(int i=0;i<3;i++)
		{
		    for(int j=0;j<2;j++){
		        System.out.println(a[i][j]);
		    }
		}
	}
}
