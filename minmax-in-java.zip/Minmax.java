import java.util.Arrays;
public class Minmax
{
	public static void main(String[] args) {
	    
	    int a[]={4546,767,55};
	  
	    
	    
		System.out.println("Integer array is"+Arrays.toString(a));
		;
			Arrays.sort(a);
				System.out.println("Sorted array is"+Arrays.toString(a));
			System.out.println("The minimum value is"+a[0]);
				System.out.println("The maximum value is"+a[a.length-1);
		
	}
}
